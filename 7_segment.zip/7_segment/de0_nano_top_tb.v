`timescale 1ns/1ps

module de0_nano_top_tb();

    // Parameters
    parameter CLK_PERIOD = 20; // 50 MHz clock

    // Testbench Signals
    reg clk;
    reg rst_button;   // Simulates KEY0
    reg tx_button;    // Simulates KEY1
    wire [6:0] hex_out;
    wire uart_tx_line;
    wire uart_rx_line;

    // Loopback: Connect TX directly to RX
    assign uart_rx_line = uart_tx_line;

    // Instantiate the Top-Level Module
    de0_nano_top uut (
        .CLOCK_50(clk),
        .KEY0(rst_button),
        .KEY1(tx_button),
        .HEX0(hex_out),
        .GPIO_0_0(uart_tx_line),
        .GPIO_0_1(uart_rx_line)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #(CLK_PERIOD/2) clk = ~clk;
    end

    // Simulation Procedure
    initial begin
        // Initialize Signals
        rst_button = 0; // Press Reset (Active Low)
        tx_button = 1;  // Button not pressed (Active Low)
        
        // 1. Apply Reset
        #(CLK_PERIOD * 10);
        rst_button = 1; // Release Reset
        #(CLK_PERIOD * 10);

        // 2. Perform 3 Increments (0 -> 1 -> 2)
        // We will repeat this 3 times to see the count go up
        repeat (11) begin
            $display("--- Pressing KEY1 to increment ---");
            
            // Press the button
            tx_button = 0;
            #(CLK_PERIOD * 20); // Hold for a few cycles
            
            // Release the button
            tx_button = 1;
            
            // Wait for the UART transmission and reception to finish
            // At 115200 baud, one byte takes ~86,000ns. 
            // We wait slightly longer to be safe.
            #89000; 
            
            $display("Current 7-segment pattern: %b", hex_out);
        end

        // 3. Test the wrap-around (Skip to 9)
        // Manually forcing the internal tx_data to 8 would be hard, 
        // so we just run the simulation long enough to see the patterns.

        $display("Simulation finished.");
        $stop; // Pause simulation
    end

endmodule