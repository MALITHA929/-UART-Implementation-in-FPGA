transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+E:/semester_04/ECD/7_segment {E:/semester_04/ECD/7_segment/uart_tx.v}
vlog -vlog01compat -work work +incdir+E:/semester_04/ECD/7_segment {E:/semester_04/ECD/7_segment/uart_top.v}

