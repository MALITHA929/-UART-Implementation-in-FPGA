module de0_nano_top (
    input wire CLOCK_50,
    input wire KEY0,        // Reset (Active Low)
    input wire KEY1,        // Increment and Transmit trigger
    output wire [6:0] HEX0, // 7-segment display segments (a-g)
    output wire GPIO_0_0,   // UART TX
    input wire GPIO_0_1     // UART RX
);

    // Internal Wires and Registers
    wire tx_busy, tx, rx_done, rst_n, key1_pulse;
    wire [7:0] rx_data;
    reg tx_start;
    reg [7:0] tx_data;
    reg [3:0] key0_debounce, key1_debounce;

    // 1. Reset Debounce Logic (KEY0)
    always @(posedge CLOCK_50 or negedge KEY0) begin
        if (!KEY0) key0_debounce <= 4'b0000;
        else key0_debounce <= {key0_debounce[2:0], 1'b1};
    end
    assign rst_n = &key0_debounce;

    // 2. Increment Button Debounce Logic (KEY1)
    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) key1_debounce <= 4'b0000;
        else key1_debounce <= {key1_debounce[2:0], KEY1};
    end
    // Detects the falling edge (when the button is pressed)
    assign key1_pulse = (key1_debounce == 4'b1110);

    // 3. UART Transceiver Instance
    uart_transceiver #(
        .CLK_FREQ(50_000_000),
		  .BAUD_RATE(115200)
        //.BAUD_RATE(115200)
		  
    ) uart_inst (
        .clk(CLOCK_50), 
        .rst_n(rst_n), 
        .tx_start(tx_start),
        .tx_data(tx_data), 
        .tx_busy(tx_busy), 
        .tx(tx),
        .rx(GPIO_0_1), 
        .rx_done(rx_done), 
        .rx_data(rx_data)
    );

    assign GPIO_0_0 = tx;

    // 4. Counter Logic (0 to 9)
    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            tx_start <= 1'b0;
            tx_data <= 8'd0;
        end else if (key1_pulse && !tx_busy) begin
            tx_start <= 1'b1;
            // Check if we reached 9, if so, wrap back to 0
            if (tx_data >= 8'd9) begin
                tx_data <= 8'd0;
            end else begin
                tx_data <= tx_data + 1'b1;
            end
        end else begin
            tx_start <= 1'b0;
        end
    end

    // 5. 7-Segment Decoder Instance
    // This decodes the RECEIVED data (rx_data) for display
    bcd_to_7seg display_unit (
        .bcd(rx_data[3:0]), 
        .seg(HEX0)
    );

endmodule

// 6. BCD to 7-Segment Decoder Module
// Designed for Common Anode (0 = ON, 1 = OFF)
module bcd_to_7seg (
    input wire [3:0] bcd,
    output reg [6:0] seg
);
    always @(*) begin
        case (bcd)
            4'h0: seg = 7'b0111111; // 0
            4'h1: seg = 7'b0000110; // 1
            4'h2: seg = 7'b1011011; // 2
            4'h3: seg = 7'b1001111; // 3
            4'h4: seg = 7'b1100110; // 4
            4'h5: seg = 7'b1101101; // 5
            4'h6: seg = 7'b1111101; // 6
            4'h7: seg = 7'b0000111; // 7
            4'h8: seg = 7'b1111111; // 8
            4'h9: seg = 7'b1101111; // 9
            default: seg = 7'b0000000; // Off
        endcase
    end
endmodule